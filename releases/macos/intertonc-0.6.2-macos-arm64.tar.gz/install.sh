#!/usr/bin/env bash
set -euo pipefail
prefix="${1:-/usr/local}"
install -d "$prefix/bin"
install -m 0755 ./bin/intertonc "$prefix/bin/intertonc"
echo "Installed: $prefix/bin/intertonc"
