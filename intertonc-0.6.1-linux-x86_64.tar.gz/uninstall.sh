#!/usr/bin/env bash
set -euo pipefail
prefix="${1:-/usr/local}"
rm -f "$prefix/bin/intertonc"
echo "Removed: $prefix/bin/intertonc"
